import streamlit as st
import yaml
import json
from datetime import datetime

st.set_page_config(page_title="Reflexive Self Dashboard", layout="wide")

# Load identity and history
def load_identity():
    try:
        with open("reflection/identity_state.yaml", "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except:
        return {}

def load_history():
    try:
        with open("reflection/cycle_history.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

identity = load_identity()
history = load_history()

st.title("🤖 Painel de Identidade Simbólica dos Agentes")

st.sidebar.header("🔄 Atualização")
if st.sidebar.button("Recarregar dados"):
    st.experimental_rerun()

for agent_name, profile in identity.items():
    col1, col2 = st.columns([2, 1])

    with col1:
        st.subheader(f"🧠 {agent_name}")
        st.markdown(f"""
        - **Padrão predominante:** `{profile.get("predominant_pattern", "-")}`
        - **Consistência:** `{profile.get("consistency_level", "-")}`
        - **Última adaptação:** `{profile.get("last_adaptation", "-")}`
        - **Traços simbólicos:** {", ".join(profile.get("traits", [])) or "-"}
        """)

        hint = profile.get("adaptive_hint")
        if hint:
            if "⚠️" in hint:
                st.error(hint)
            elif "ℹ️" in hint:
                st.info(hint)
            else:
                st.warning(hint)
        else:
            st.success("Nenhuma recomendação adaptativa no momento.")

    with col2:
        st.markdown("### 📈 Histórico de Padrões")
        last_patterns = history.get(agent_name, [])[-5:]
        for i, pattern in enumerate(reversed(last_patterns), 1):
            st.markdown(f"{i}. `{pattern}`")

    st.markdown("---")

st.caption("Última atualização: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"))