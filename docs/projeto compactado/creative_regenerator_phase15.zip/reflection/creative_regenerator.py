import yaml
from datetime import datetime

FILES = {
    "identity": "reflection/identity_state.yaml",
    "emotion": "reflection/emotional_state.yaml",
    "review": "reflection/supervisor_self_reflection.yaml",
    "output": "reflection/creative_regeneration.yaml"
}

class CreativeRegenerator:
    def __init__(self):
        self.identity = self.load(FILES["identity"])
        self.emotion = self.load(FILES["emotion"])
        self.review = self.load(FILES["review"])

    def load(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except:
            return {}

    def propose_creative_action(self):
        ciclo = self.emotion.get("emotional_state", {}).get("ciclo", 0)
        estado = self.emotion.get("emotional_state", {}).get("status", "")
        revisão = self.review.get("reflexão_supervisor", {}).get("revisão", "")

        proposta, motivação = self.generate_from_state(estado, revisão)

        resultado = {
            "regeneração_criativa": {
                "ciclo": ciclo,
                "proposta": proposta,
                "motivação": motivação,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
        }

        with open(FILES["output"], "w", encoding="utf-8") as f:
            yaml.safe_dump(resultado, f, allow_unicode=True)

        self.print_regeneration(resultado["regeneração_criativa"])

    def generate_from_state(self, estado, revisão):
        if estado == "Estagnado":
            return (
                "Forçar um novo padrão disruptivo com variação aleatória entre os agentes.",
                "Estagnação detectada com repetição de diagnósticos anteriores."
            )
        elif estado == "Cauteloso":
            return (
                "Reforçar traços simbólicos estáveis e reduzir complexidade.",
                "Estado emocional cauteloso com histórico de falhas."
            )
        elif estado == "Curioso":
            return (
                "Explorar padrões alternativos não utilizados até agora.",
                "Sistema aberto a variação, sem anomalias críticas."
            )
        elif estado == "Frustrado":
            return (
                "Reconfigurar agentes com novos prompts ou estruturas internas.",
                "Frustração simbólica com pouca diversidade de resultados."
            )
        elif estado == "Confiante":
            return (
                "Tentar integração criativa entre agentes para tarefa conjunta.",
                "Consistência alta e diversidade simbólica favorável."
            )
        return (
            "Executar tarefa simbólica alternativa ao padrão atual.",
            "Estado indefinido ou neutro. Proposta padrão gerada."
        )

    def print_regeneration(self, data):
        print("\n✨ [REGENERAÇÃO CRIATIVA]")
        print(f"📅 Ciclo: {data['ciclo']} | 🕓 {data['timestamp']}")
        print(f"🧠 Proposta: {data['proposta']}")
        print(f"🎯 Motivação: {data['motivação']}")