# Project Overview

Reflexive Self Assistant is a symbolic multi-agent system designed to simulate a recursive selfhood loop using agents capable of adaptation, reflection, supervision, and self-narrative. It is an experiment in symbolic autonomy, identity evolution and controlled agent architecture for decision support and meta-programming.