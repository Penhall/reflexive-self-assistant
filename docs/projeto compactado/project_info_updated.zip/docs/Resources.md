# Resources

- Neo4j: Optional graph storage
- YAML files: All symbolic states and decisions
- Streamlit dashboard
- Logs and snapshots: reports, alerts, identities
- GitHub repository (to be configured)
- Agent structure + reflection cycle diagram (in roadmap)