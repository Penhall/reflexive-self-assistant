"""
Agente reflexivo que analisa padrões e atualiza a identidade simbólica do sistema.
"""

from utils.graph_interface import GraphMemory

class ReflectionAgent:
    def __init__(self):
        self.graph = GraphMemory()

    def reflect_on_tasks(self, agents):
        print("🔁 Iniciando reflexão simbólica sobre os agentes...")

        for agent in agents:
            reaction = agent.latest_output
            pattern = self.identify_pattern(reaction)
            category = self.categorize_pattern(pattern)
            agent_name = agent.__class__.__name__

            print(f"Registrando padrão: '{pattern}' para agente: {agent_name}")
            self.graph.register_pattern(reaction, pattern, category, agent_name)

        print("✅ Reflexão concluída.
")

    def identify_pattern(self, text):
        """
        Simula identificação de padrão a partir da saída do agente.
        """
        if "erro" in text.lower():
            return "Comportamento anômalo"
        elif "documentação" in text.lower():
            return "Atualização documental"
        elif "testes" in text.lower():
            return "Cobertura de teste"
        else:
            return "Execução padrão"

    def categorize_pattern(self, pattern):
        """
        Classifica o padrão em uma categoria simbólica.
        """
        mapping = {
            "Comportamento anômalo": "Falha",
            "Atualização documental": "Documentação",
            "Cobertura de teste": "Testes",
            "Execução padrão": "Operação"
        }
        return mapping.get(pattern, "Outro")

    def close(self):
        self.graph.close()